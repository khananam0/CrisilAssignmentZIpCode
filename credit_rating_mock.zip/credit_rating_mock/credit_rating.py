def calculate_credit_rating(mortgages):
    print(mortgages, "========mortgages=====")
    total_risk_score = 0

    # Loop through each mortgage and calculate risk score
    for mortgage in mortgages:
        risk_score = 0

        # Loan-to-Value (LTV) Ratio
        ltv = mortgage["loan_amount"] / mortgage["property_value"]
        if ltv > 0.9:
            risk_score += 2
        elif ltv > 0.8:
            risk_score += 1

        # Debt-to-Income (DTI) Ratio
        dti = mortgage["debt_amount"] / mortgage["annual_income"]
        if dti > 0.5:
            risk_score += 2
        elif dti > 0.4:
            risk_score += 1

        # Credit Score
        credit_score = mortgage["credit_score"]
        if credit_score >= 700:
            risk_score -= 1
        elif credit_score < 650:
            risk_score += 1

        # Loan Type
        loan_type = mortgage["loan_type"]
        if loan_type == "fixed":
            risk_score -= 1
        elif loan_type == "adjustable":
            risk_score += 1

        # Property Type
        property_type = mortgage["property_type"]
        if property_type == "condo":
            risk_score += 1

        # Add the calculated risk score to the total
        total_risk_score += risk_score

    # Adjust total score based on the average credit score
    average_credit_score = sum([mortgage["credit_score"] for mortgage in mortgages]) / len(mortgages)
    if average_credit_score >= 700:
        total_risk_score -= 1
    elif average_credit_score < 650:
        total_risk_score += 1

    # Determine final credit rating
    if total_risk_score <= 2:
        return "AAA"
    elif 3 <= total_risk_score <= 5:
        return "BBB"
    else:
        return "C"
    

mortgages = [
    {
        "credit_score": 750,
        "loan_amount": 200000,
        "property_value": 250000,
        "annual_income": 60000,
        "debt_amount": 20000,
        "loan_type": "fixed",
        "property_type": "single_family"
    },
    {
        "credit_score": 680,
        "loan_amount": 150000,
        "property_value": 175000,
        "annual_income": 45000,
        "debt_amount": 10000,
        "loan_type": "adjustable",
        "property_type": "condo"
    }
]

print(calculate_credit_rating(mortgages))  # Expected Output: "AAA"