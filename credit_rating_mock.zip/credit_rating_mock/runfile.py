from credit_rating1 import calculate_credit_rating

mortgages = [
    {
        "credit_score": 750,
        "loan_amount": 200000,
        "property_value": 250000,
        "annual_income": 60000,
        "debt_amount": 20000,
        "loan_type": "fixed",
        "property_type": "single_family"
    },
    {
        "credit_score": 680,
        "loan_amount": 150000,
        "property_value": 175000,
        "annual_income": 45000,
        "debt_amount": 10000,
        "loan_type": "adjustable",
        "property_type": "condo"
    }
]

print(calculate_credit_rating(mortgages))